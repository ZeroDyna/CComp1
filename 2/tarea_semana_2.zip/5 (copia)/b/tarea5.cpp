#include <iostream>
using namespace std;
//solo se me ocurrio usar bucles for 
int main() {
    for (int i = 0; i < 4; i++) {
        std::cout << "* * * * * * * *\n";
        std::cout << " * * * * * * * *\n";
    }
    return 0;
}

