#include <iostream>

int main() {
    std::cout << "   ccc               +            +" << std::endl;
    std::cout << "  c                  +            +" << std::endl;
    std::cout << " c                 +++++        +++++" << std::endl;
    std::cout << "  c                  +            +" << std::endl;
    std::cout << "   ccc               +            +" << std::endl;
    return 0;
}
